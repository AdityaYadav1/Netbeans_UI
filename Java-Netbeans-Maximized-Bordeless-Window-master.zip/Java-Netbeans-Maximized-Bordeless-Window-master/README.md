# Java-Netbeans-Maximized-Bordeless-Window
Using swing and GUI builder. Something interesting comes up
